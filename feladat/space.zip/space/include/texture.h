#ifndef TEXTURE_H
#define TEXTURE_H

#include <glad/glad.h>

GLuint loadTexture(const char *path);

#endif